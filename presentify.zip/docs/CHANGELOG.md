# Changelog

Semua perubahan penting pada proyek Presentify dicatat di sini.

---

## [Unreleased] — Fase 1: Core System, Dynamic Engine & Workflow

### 2026-11-24

#### Diperbarui — Migrasi ke stancl/tenancy (penyesuaian Langkah 1.1)

**Package**
- `stancl/tenancy` v3.10.1 diinstall (`stancl/virtualcolumn`, `stancl/jobpipeline` sebagai dependency).

**Migrasi — dimodifikasi / ditambah**
- `2019_09_15_000010_create_sys_tenants_table.php` — menggantikan migrasi manual lama; `sys_tenants` kini memakai UUID string PK dan kolom `data` JSON untuk virtual columns (theme_config, terminology, logo_path, favicon_path).
- `2019_09_15_000020_create_sys_domains_table.php` — tabel `sys_domains` (FK ke `sys_tenants.id` string UUID); menggantikan tabel `domains` default stancl.
- `2026_11_24_000002_create_sys_tenant_user_table.php` — FK `tenant_id` diubah dari `bigint` menjadi `string` agar kompatibel dengan UUID `sys_tenants.id`.

**Model Eloquent — diperbarui / ditambah**
- `app/Models/Tenant.php` — kini extends `BaseTenant` (stancl) + traits `HasDatabase` + `HasDomains`; virtual columns `theme_config`, `terminology`, `logo_path`, `favicon_path` disimpan di kolom `data` JSON via VirtualColumn.
- `app/Models/Domain.php` *(baru)* — extends `BaseDomain` (stancl), `protected $table = 'sys_domains';`.
- `app/Models/TenantUser.php` — `tenant_id` diubah ke `string`.

**Konfigurasi & Provider**
- `config/tenancy.php` — dikonfigurasi dengan model `Tenant` & `Domain` kustom, `central_domains`, dan prefix DB `presentify_tenant_`.
- `app/Providers/TenancyServiceProvider.php` — dirapikan (typed return, komentar slop dihapus).
- `routes/tenant.php` — middleware diubah ke `InitializeTenancyBySubdomain` + `PreventAccessFromCentralDomains`.
- `database/seeders/CentralDatabaseSeeder.php` — seeder menggunakan `$tenant->domains()->create()` via stancl HasDomains.

**Verifikasi**
- `php artisan test`: 42 passed, 147 assertions ✓
- `npm run build`: built in 18.48s, 2328 modules ✓

**Migrasi (Central DB)**
- `database/migrations/2026_11_24_000001_create_sys_tenants_table.php` — tabel `sys_tenants` menyimpan profil instansi, konfigurasi tema, dan kamus terminologi.
- `database/migrations/2026_11_24_000002_create_sys_tenant_user_table.php` — pivot `sys_tenant_user` memetakan user global ke tenant.
- `database/migrations/2026_11_24_000003_create_auth_otp_tokens_table.php` — tabel `auth_otp_tokens` menyimpan hash SHA-256 token OTP email (TTL 5 menit).
- `database/migrations/2026_11_24_000004_create_auth_sso_tokens_table.php` — tabel `auth_sso_tokens` menyimpan one-time SSO token (TTL 30–60 detik, single-use).

**Model Eloquent**
- `app/Models/Tenant.php` — model `sys_tenants` dengan casting JSON untuk `theme_config` dan `terminology`, relasi ke `User` dan `TenantUser`.
- `app/Models/TenantUser.php` — model `sys_tenant_user` dengan relasi `tenant()` dan `user()`.
- `app/Models/OtpToken.php` — model `auth_otp_tokens` dengan method `isValid()` untuk validasi TTL dan status penggunaan.
- `app/Models/SsoToken.php` — model `auth_sso_tokens` dengan method `isValid()` dan relasi ke `Tenant` via `targetTenant()`.
- `app/Models/User.php` — ditambah relasi `tenants()`, `activeTenants()`, `tenantUsers()`, `otpTokens()`, `ssoTokens()` ke model-model Central DB.

**Seeder**
- `database/seeders/CentralDatabaseSeeder.php` — seeder 2 user (Superadmin, Demo User), 2 tenant contoh (Dinas Kependudukan & SMA Negeri 1) lengkap dengan konfigurasi tema dan terminologi awal.
- `database/seeders/DatabaseSeeder.php` — diperbarui untuk memanggil `CentralDatabaseSeeder`.

**Verifikasi**
- `php artisan test`: 42 passed, 147 assertions ✓
- `npm run build`: built in 20.18s, 2328 modules ✓
