<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('auth_sso_tokens', function (Blueprint $table) {
            $table->id();
            // Cryptographically random token hash — deleted immediately after use
            $table->string('token_hash')->unique();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('target_tenant_id')->constrained('sys_tenants')->cascadeOnDelete();
            $table->timestamp('expires_at');
            $table->timestamp('used_at')->nullable();
            $table->timestamps();

            $table->index(['token_hash', 'expires_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('auth_sso_tokens');
    }
};
