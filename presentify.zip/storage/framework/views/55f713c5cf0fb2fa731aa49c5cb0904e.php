<?php echo e($slot); ?>

<?php /**PATH F:\laravel\presentify\vendor\laravel\framework\src\Illuminate\Mail\resources\views\text/footer.blade.php ENDPATH**/ ?>