# Panduan Operasional AI Agent & Arsitektur Proyek (AGENTS.md)

Dokumen ini adalah pedoman wajib bagi AI Agent yang bekerja pada repositori **Presentify (Sistem Presensi Dinamis Multi-Tenant)**. Seluruh instruksi, batasan, dan alur kerja di bawah ini harus dipatuhi secara konsisten.

---

## 1. Ringkasan Tech Stack

Proyek ini dibangun menggunakan **Laravel React Starter Kit** modern dengan dependensi utama:

### Backend
* **Framework:** Laravel 13.x (PHP ^8.3)
* **Authentication & Keamanan:** Laravel Fortify (`^1.37.2`), Passkeys (`@laravel/passkeys`)
* **Full-stack Adapter:** Inertia.js Laravel (`^3.0`)
* **Routing & Types:** Laravel Wayfinder (`^0.1.14`), Laravel Chisel
* **Testing & Code Quality:** Pest PHP (`^4.7`), Pest Plugin Laravel, PHPStan / Larastan (`^3.9`), Laravel Pint

### Frontend
* **UI Framework:** React 19 (`^19.2.0`), TypeScript (`^5.7.2`), React Compiler (`babel-plugin-react-compiler`)
* **Inertia Adapter:** `@inertiajs/react` (`^3.0.0`)
* **Bundler & Tooling:** Vite Plus / Vite Core (`@voidzero-dev/vite-plus-core` / `vite-plus`)
* **Styling:** Tailwind CSS v4 (`@tailwindcss/vite`, `tw-animate-css`)
* **Komponen & Desain Sistem:** shadcn/ui (berbasis Radix UI primitives: Dialog, Dropdown Menu, Select, Collapsible, Navigation Menu, Tooltip, Avatar, dll.)
* **Ikonografi & Input:** Lucide React (`lucide-react`), OTP Input (`input-otp`), Sonner Toast (`sonner`), Class Variance Authority (`cva`), `clsx`, `tailwind-merge`

### Lingkungan & Kontainer
* **Database Engine:** Multi-DB (Central DB & Tenant DBs terpisah)
* **Dev Environment:** Docker & Docker Compose (`php-fpm`, `nginx`, `vite`, `queue worker`)

---

## 2. Arsitektur Inti dari PRD

Presentify dirancang untuk memenuhi kebutuhan presensi lintas instansi (Pemerintah, Kampus/Sekolah, Rumah Sakit, Swasta) dengan fleksibilitas tinggi tanpa coding ulang.

### 2.1 Model Isolasi & Database Multi-Tenant
* **Arsitektur Hybrid Central + Database-per-Tenant:**
  * **Central Database:** Menyimpan data global lintas tenant, yaitu identitas user (`users`), token OTP email (`otp_tokens`), token SSO sekali pakai (`sso_tokens`), daftar instansi (`tenants`), dan relasi akses (`tenant_user`).
  * **Tenant Database (Terpisah per Instansi):** Setiap tenant memiliki database SQL sendiri dengan subdomain routing (`{tenant}.domain.com`). Berisi tabel lokal seperti `members`, `units`, `menus`, `roles`, `permissions`, `attendance_policies`, `attendances`, `leave_requests`, `approval_workflows`, `delegations`, dan `audit_logs`.
* **Central SSO & Routing:**
  * Login terpusat di `app.domain.com/login` (Password & OTP Email 6-digit).
  * Pemakai 1 tenant langsung diarahkan via *One-Time SSO Token* (TTL 30–60 detik).
  * Pemakai multi-tenant diarahkan ke *Workspace/Tenant Picker*, dengan fitur *Instansi Switcher* di sidebar dan *Single Logout (SLO)*.
* **White-Label UI & Kamus Terminologi:**
  * Kustomisasi logo, nama instansi, dan palet warna yang diinjeksi ke CSS variables shadcn/ui (`--primary`, `--accent`, `--radius`).
  * Kamus istilah dinamis per tenant (misal: "Pegawai" vs "Karyawan" vs "Siswa", "Divisi" vs "Kelas").

### 2.2 Role-Based Access Control (RBAC) & Menu Dinamis
* **5 Role Standar:** Superadmin SaaS (Central), Admin Tenant, Atasan/Verifikator, Pegawai/Anggota, dan Akun Kiosk.
* **2-Tier Permission System:**
  1. *Menu-Bound Permission (`menu_id != null`):* Aksi spesifik pada menu (view, create, edit, delete, export, import).
  2. *Global Permission (`menu_id = null`):* Hak akses lintas modul (misal: bypass geofence, override kehadiran, reset device, approval lintas unit).
* **Dynamic Sidebar Menu:** Menu sistem dikelola via master registry dengan kemampuan Admin Tenant mengubah label tampilan (`custom_label`), ikon (`icon`), urutan (`sort_order`), dan hierarki (`parent_id`) tanpa merusak route asli.
* **Hierarki Organisasi & Delegasi:** Unit kerja bertingkat dengan pola *Parent ID + Materialized Path* (`path`, `depth`) untuk efisiensi query hierarki bawahan, serta tabel *Delegasi Sementara* untuk pelaksana tugas (Plt.).

### 2.3 Fase Roadmap Produk
* **Fase 1 (Core & Fondasi):** Central SSO, Multi-DB Tenancy, Dynamic Role & Menu Builder, Unit Hierarchy & Delegasi, Dynamic Policy Engine.
* **Fase 2 (Smart Integrity & Kiosk):** Client-Side Liveness Detection (WebRTC), Device Fingerprint & Geofencing Anomaly, Offline-First PWA (IndexedDB + Signed Payload), Mode Kiosk (Dynamic QR TOTP).
* **Fase 3 (AI Asinkron):** AI Fraud Scoring (Laravel Queue), AI OCR Validator Surat Izin/Sakit, AI Command Bar (`Cmd+K`).
* **Fase 4 (Enterprise):** Early Warning Burnout, AI Shift & Roster Optimizer, AI Briefing Pimpinan.

---

## 3. Aturan Wajib Operasional AI Agent

Setiap AI Agent yang berinteraksi dalam repositori ini **WAJIB** mematuhi 3 aturan utama berikut:

### Aturan 1: Perencanaan Terstruktur di `docs/plans/`
* Setiap kali diminta membuat *plan* atau sebelum mengeksekusi fitur/tugas baru yang kompleks, buat file rencana terpisah di direktori `docs/plans/` (misal: `docs/plans/<nama-fitur>.md`).
* Rencana harus berbentuk **checklist kecil** yang modular, spesifik, dan terurut.
* Pastikan direktori `docs/plans/` dibuat jika belum ada.

### Aturan 2: Eksekusi 1 Langkah per Giliran (Step-by-Step)
* Kerjakan **hanya 1 langkah (task) per giliran (turn)**.
* Setelah menyelesaikan satu langkah, laporkan ringkasan hasil kerja secara padat dan jelas.
* **Tunggu konfirmasi atau persetujuan pengguna** sebelum melanjutkan ke langkah berikutnya. Jangan pernah mengeksekusi langkah berikutnya secara mandiri tanpa instruksi lanjutan.

### Aturan 3: Verifikasi Kualitas Sebelum Mencatat ke `docs/CHANGELOG.md`
* Setiap kali sebuah langkah atau pekerjaan selesai dan akan didokumentasikan, agen **WAJIB** menjalankan verifikasi:
  1. `php artisan test` (memastikan seluruh unit & feature test backend lulus).
  2. `npm run build` (memastikan tidak ada error kompilasi TypeScript, Vite, atau Tailwind CSS).
* **Dilarang mencatat progres ke `docs/CHANGELOG.md` jika salah satu dari perintah di atas gagal/error!**
* Jika terjadi error, perbaiki terlebih dahulu sampai semua pengujian dan build berhasil 100%.
* Setelah verifikasi sukses, barulah progres, pembaruan fitur, atau perbaikan dicatat secara rapi ke `docs/CHANGELOG.md`.

## Table Prefix Conventions
Kelompokkan nama tabel menggunakan prefix sesuai domainnya (tetap plural `snake_case`, kecuali pivot singular urut alfabet):
- `sys_` : Tabel orkestrasi SaaS di Central DB (`sys_tenants`, `sys_domains`, `sys_tenant_user`).
- `auth_` : Autentikasi, SSO & perangkat (`auth_otp_tokens`, `auth_sso_tokens`, `auth_trusted_devices`, `auth_kiosk_devices`).
- `rbac_` : Hak akses & menu (`rbac_roles`, `rbac_permissions`, `rbac_menus`, `rbac_role_has_permissions`, `rbac_model_has_roles`).
- `org_` : Struktur organisasi & anggota (`org_units`, `org_members`, `org_delegations`).
- `att_` : Presensi & pengajuan (`att_policies`, `att_attendances`, `att_leave_requests`).
- `wf_` : Approval workflow (`wf_workflows`, `wf_approvals`).
- `log_` : Audit & jejak aktivitas (`log_audit_trails`).
- `ai_` : Pemrosesan AI (`ai_fraud_scores`, `ai_ocr_jobs`, `ai_briefings`).

Catatan Laravel:
- Tabel bawaan autentikasi Laravel (`users`, `sessions`, `password_reset_tokens`) tetap memakai nama standar agar kompatibel dengan Starter Kit/Fortify.
- Setiap Model Eloquent yang memakai prefix wajib mendefinisikan `protected $table = '...';`.
- Jika memakai `spatie/laravel-permission`, sesuaikan nama tabel `rbac_*` di `config/permission.php`.

## Architecture: Thin Controller & OOP Service Layer
- **Controller wajib tipis (Thin Controller):** Controller hanya boleh melakukan 3 hal: validasi input via `FormRequest`, memanggil class `Service`, dan mengembalikan response (`Inertia::render` atau `redirect`). Dilarang menaruh query Eloquent kompleks, `DB::transaction`, atau logika bisnis di dalam Controller.
- **OOP Service Layer (`app/Services/<Domain>/`):** Seluruh logika bisnis, kalkulasi, transaksi database, dan orkestrasi antar model wajib ditempatkan di dalam class Service yang fokus (contoh: `App\Services\Auth\SsoService`, `App\Services\Rbac\RoleBuilderService`, `App\Services\Organization\UnitHierarchyService`).
- **Dependency Injection & DTO:** Inject Service melalui constructor atau method Controller, gunakan method dengan tanggung jawab tunggal (*Single Responsibility*), dan manfaatkan *FormRequest* / *Data Object* untuk transfer data yang bersih.

<!-- antislop:start -->
## antislop
For UI, copy, people, mobile layout, or code comments work, read these installed skill files directly (use these paths even if a same-named global skill exists):
- Core filter, always on: `antislop`: `.agents/skills/antislop/SKILL.md`
- UI / visual: `antislop-ui`: `.agents/skills/antislop-ui/SKILL.md`
- Code comments: `antislop-code`: `.agents/skills/antislop-code/SKILL.md`
Before starting, follow the core's "Two Usage Modes" section in strict order: explicit session instruction first, then global preference, then ask. A session instruction always wins. For a resolved mode, say `antislop active: <mode> (session override).` or `antislop active: <mode> (global preference).` once before presenting findings or making edits, using the actual mode and source. Acknowledging the user's request without naming the source does not replace this notice.
Only an explicit choice of antislop during or after selects a session mode. A request to review, audit, or avoid file edits does not select a mode; read the global preference in that case. Another skill's mode does not select antislop's mode.
If the mode is unresolved, ask during/after and end the response; wait for the answer before any UI review, planning, or concept. For read-only tasks, put the active-mode notice only at the start of the final answer, never in progress messages. For editing tasks, announce before the first edit and omit it from the final answer.
To update antislop later: `npx antislop-ai --update`, or run `npx antislop-ai` and pick Overwrite them.
<!-- antislop:end -->
