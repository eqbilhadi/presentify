<?php

namespace App\Models;

use Stancl\Tenancy\Database\Models\Domain as BaseDomain;

/**
 * @property int    $id
 * @property string $domain  Full hostname or subdomain (e.g. disdukcapil.presentify.test)
 * @property string $tenant_id
 */
class Domain extends BaseDomain
{
    protected $table = 'sys_domains';
}
